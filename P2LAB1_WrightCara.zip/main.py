# Read gas mileage and cost of gas
gas_mileage = float(input())
gas_cost = float(input())

# Calculate the gas cost for different distances
gas_cost_20_miles = 20 / gas_mileage * gas_cost
gas_cost_75_miles = 75 / gas_mileage * gas_cost
gas_cost_500_miles = 500 / gas_mileage * gas_cost

# Print the results with two decimal places
print(f'{gas_cost_20_miles:.2f} {gas_cost_75_miles:.2f} {gas_cost_500_miles:.2f}')


